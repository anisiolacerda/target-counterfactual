#!/bin/bash
# S7.2 Artificial Hidden Confounding Experiment
# Run on Vast.ai instance: ssh -p 25003 root@69.157.137.231
#
# This script:
# 1. Sets up the Python environment
# 2. Extracts VCIP code
# 3. Patches dataset.py to zero out patient_types (simulating hidden confounding)
# 4. Trains VCIP for gamma=4, 5 seeds
# 5. Runs RA evaluation to get traj_features + safety rates

set -e

echo "=== S7.2: Setting up environment ==="

# Create venv if not exists
if [ ! -d /root/vcip_env ]; then
    python3 -m venv /root/vcip_env
fi
source /root/vcip_env/bin/activate

# Install dependencies
pip install --quiet torch torchvision --index-url https://download.pytorch.org/whl/cu124
pip install --quiet pytorch-lightning==2.0.7 hydra-core==1.3.2 omegaconf==2.3.0 \
    scikit-learn scipy pandas torchmetrics==1.5.2

# Verify GPU
python -c "import torch; print(f'CUDA: {torch.cuda.is_available()}, GPUs: {torch.cuda.device_count()}, Device: {torch.cuda.get_device_name(0)}')"

echo "=== Extracting code ==="
mkdir -p /root/VCIP && cd /root/VCIP
tar xzf /root/vcip_code.tar.gz

echo "=== Applying hidden confounding patch ==="
# Patch: zero out patient_types when HIDE_PATIENT_TYPES env var is set
cat > /root/hide_patient_types.patch << 'PATCHEOF'
--- a/src/data/cancer_sim_cont/dataset.py
+++ b/src/data/cancer_sim_cont/dataset.py
@@ -1,4 +1,5 @@
 import numpy as np
+import os
 from torch.utils.data import Dataset
 import logging
 from copy import deepcopy
@@ -119,6 +120,10 @@
             cancer_volume = (self.data['cancer_volume'] - mean['cancer_volume']) / std['cancer_volume']
             patient_types = (self.data['patient_types'] - mean['patient_types']) / std['patient_types']

+            # S7.2: Zero out patient_types to simulate hidden confounding
+            if os.environ.get('HIDE_PATIENT_TYPES', '0') == '1':
+                logger.warning("HIDE_PATIENT_TYPES=1: Zeroing out patient_types to simulate hidden confounding")
+                patient_types = np.zeros_like(patient_types)
+
             patient_types = np.stack([patient_types for t in range(cancer_volume.shape[1])], axis=1)
PATCHEOF

# Apply patch manually (more robust than patch command)
cd /root/VCIP
python3 << 'PYEOF'
import os

fpath = 'src/data/cancer_sim_cont/dataset.py'
with open(fpath, 'r') as f:
    content = f.read()

# Add os import if not present
if 'import os' not in content:
    content = content.replace('import numpy as np', 'import numpy as np\nimport os')

# Add hidden confounding patch after patient_types normalization
old = "            patient_types = (self.data['patient_types'] - mean['patient_types']) / std['patient_types']\n\n            patient_types = np.stack"
new = """            patient_types = (self.data['patient_types'] - mean['patient_types']) / std['patient_types']

            # S7.2: Zero out patient_types to simulate hidden confounding
            if os.environ.get('HIDE_PATIENT_TYPES', '0') == '1':
                logger.warning("HIDE_PATIENT_TYPES=1: Zeroing out patient_types to simulate hidden confounding")
                patient_types = np.zeros_like(patient_types)

            patient_types = np.stack"""

if old in content:
    content = content.replace(old, new)
    with open(fpath, 'w') as f:
        f.write(content)
    print("Patch applied successfully")
else:
    print("WARNING: Could not find patch target. Manual inspection needed.")
    # Check if already patched
    if 'HIDE_PATIENT_TYPES' in content:
        print("Already patched!")
    else:
        print("ERROR: Unexpected file contents")
PYEOF

echo "=== Verifying patch ==="
grep -n "HIDE_PATIENT_TYPES" src/data/cancer_sim_cont/dataset.py

echo ""
echo "=== Setup complete. Ready to train. ==="
echo "To train with hidden confounding:"
echo "  HIDE_PATIENT_TYPES=1 python runnables/train_vae.py ..."
echo "To train normally (baseline):"
echo "  python runnables/train_vae.py ..."
