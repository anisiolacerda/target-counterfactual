#!/bin/bash
# S7.2: Train VCIP with hidden patient_types (gamma=4, all seeds)
# Run AFTER s72_setup_and_run.sh

set -e
source /root/vcip_env/bin/activate
cd /root/VCIP

SEEDS=(10 101 1010 10101 101010)
GAMMA=4

echo "=== S7.2: Training VCIP with HIDE_PATIENT_TYPES=1 (gamma=$GAMMA) ==="
echo "Start time: $(date)"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Training seed=$SEED ($(date)) ---"

    HIDE_PATIENT_TYPES=1 CUDA_VISIBLE_DEVICES=0 python runnables/train_vae.py \
        +dataset=cancer_sim_cont \
        +model=vcip \
        "+model/hparams/cancer=4*" \
        exp.seed=$SEED \
        exp.epochs=100 \
        dataset.coeff=$GAMMA \
        model.name=VCIP \
        exp.test=False \
        exp.rank=True \
        "+exp.reach_avoid.target_upper=3.0" \
        "+exp.reach_avoid.safety_volume_upper=12.0" \
        "+exp.reach_avoid.safety_chemo_upper=5.0" \
        "+exp.reach_avoid.kappa=10.0" \
        2>&1 | tail -5

    echo "Seed $SEED complete."
done

echo ""
echo "=== All training complete. $(date) ==="

# Verify outputs exist
echo ""
echo "=== Verifying outputs ==="
for SEED in "${SEEDS[@]}"; do
    PKL="my_outputs/cancer_sim_cont/22/coeff_4/VCIP/train/True/case_infos/$SEED/False/case_infos_VCIP.pkl"
    if [ -f "$PKL" ]; then
        echo "  seed=$SEED: OK ($(ls -lh $PKL | awk '{print $5}'))"
    else
        echo "  seed=$SEED: MISSING!"
    fi
done

# Quick analysis
echo ""
echo "=== Quick safety analysis ==="
python3 << 'PYEOF'
import pickle, numpy as np, os

BASE = 'my_outputs/cancer_sim_cont/22/coeff_4'
SEEDS = [10, 101, 1010, 10101, 101010]
TAUS = [2, 4, 6, 8]
TARGET_UPPER = 3.0
SAFETY_VOL_UPPER = 12.0
SAFETY_CHEMO_UPPER = 5.0

print("Safety rates with HIDDEN patient_types (gamma=4):")
print(f"{'tau':>4} | {'ELBO safe':>10} | {'RA safe':>10} | {'n':>5}")
print("-" * 40)

for tau in TAUS:
    total = 0
    elbo_safe = 0
    ra_safe = 0

    for seed in SEEDS:
        pkl = os.path.join(BASE, f'VCIP/train/True/case_infos/{seed}/False/case_infos_VCIP.pkl')
        if not os.path.exists(pkl):
            continue
        with open(pkl, 'rb') as f:
            data = pickle.load(f)['VCIP']
        if tau not in data:
            continue
        for case in data[tau]:
            tf = case['traj_features']
            ml = case['model_losses']

            # ELBO selection
            elbo_idx = np.argmin(ml)
            cv_t = tf['cv_terminal'][elbo_idx]
            cv_m = tf['cv_max'][elbo_idx]
            cd_m = tf['cd_max'][elbo_idx]
            e_safe = (cv_t <= TARGET_UPPER) and (cv_m <= SAFETY_VOL_UPPER) and (cd_m <= SAFETY_CHEMO_UPPER)

            # RA selection
            feas = (tf['cv_terminal'] <= TARGET_UPPER) & \
                   (tf['cv_max'] <= SAFETY_VOL_UPPER) & \
                   (tf['cd_max'] <= SAFETY_CHEMO_UPPER)
            if feas.sum() > 0:
                r_safe = True
            else:
                r_safe = e_safe

            total += 1
            if e_safe:
                elbo_safe += 1
            if r_safe:
                ra_safe += 1

    if total > 0:
        print(f"{tau:>4} | {elbo_safe/total:>9.1%} | {ra_safe/total:>9.1%} | {total:>5}")

print("\nOriginal (with patient_types) SR_0 values for comparison:")
print("  tau=2: 94.4%, tau=4: 95.6%, tau=6: 97.0%, tau=8: 97.0%")
PYEOF

echo ""
echo "=== Done. Tar results for download: ==="
echo "cd /root/VCIP && tar czf /root/s72_results.tar.gz my_outputs/cancer_sim_cont/22/coeff_4/VCIP/train/True/case_infos/"
