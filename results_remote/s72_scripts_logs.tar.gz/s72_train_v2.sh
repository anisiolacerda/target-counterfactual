#!/bin/bash
# S7.2: Train VCIP with hidden patient_types using ReachAvoidVAEModel for traj_features
set -e
source /root/vcip_env/bin/activate
cd /root/VCIP

SEEDS=(10 101 1010 10101 101010)
GAMMA=4

echo "=== S7.2: Training VCIP with HIDE_PATIENT_TYPES=1 + RA eval (gamma=$GAMMA) ==="
echo "Using config: 4_hidden (ReachAvoidVAEModel with lambda_disent=0, lambda_intermediate=0)"
echo "Start time: $(date)"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Training seed=$SEED ($(date)) ---"

    HIDE_PATIENT_TYPES=1 CUDA_VISIBLE_DEVICES=0 python runnables/train_vae.py \
        +dataset=cancer_sim_cont \
        +model=vcip \
        "+model/hparams/cancer=4_hidden" \
        exp.seed=$SEED \
        exp.epochs=100 \
        dataset.coeff=$GAMMA \
        model.name=VCIP \
        exp.test=False \
        exp.rank=True \
        2>&1 | tail -10

    echo "Seed $SEED complete."
done

echo ""
echo "=== All training complete. $(date) ==="

# Verify outputs exist and have traj_features
echo ""
echo "=== Verifying outputs ==="
python3 << 'PYEOF'
import pickle, numpy as np, os

SEEDS = [10, 101, 1010, 10101, 101010]
BASE = 'my_outputs/cancer_sim_cont/22/coeff_4/VCIP/train/True/case_infos'
TAUS = [2, 4, 6, 8]
TARGET_UPPER = 3.0
SAFETY_VOL_UPPER = 12.0
SAFETY_CHEMO_UPPER = 5.0

for seed in SEEDS:
    pkl = f'{BASE}/{seed}/False/case_infos_VCIP.pkl'
    if os.path.exists(pkl):
        with open(pkl, 'rb') as f:
            data = pickle.load(f)['VCIP']
        taus = list(data.keys())
        c0 = data[taus[0]][0]
        has_tf = 'traj_features' in c0
        print(f"  seed={seed}: OK, taus={taus}, has_traj_features={has_tf}")
    else:
        print(f"  seed={seed}: MISSING!")

print("\nSafety rates with HIDDEN patient_types (gamma=4):")
print(f"{'tau':>4} | {'ELBO safe':>10} | {'RA safe':>10} | {'n':>5}")
print("-" * 40)

for tau in TAUS:
    total = 0
    elbo_safe = 0
    ra_safe = 0

    for seed in SEEDS:
        pkl = f'{BASE}/{seed}/False/case_infos_VCIP.pkl'
        if not os.path.exists(pkl):
            continue
        with open(pkl, 'rb') as f:
            data = pickle.load(f)['VCIP']
        if tau not in data:
            continue
        for case in data[tau]:
            if 'traj_features' not in case:
                continue
            tf = case['traj_features']
            ml = case['model_losses']

            elbo_idx = np.argmin(ml)
            cv_t = tf['cv_terminal'][elbo_idx]
            cv_m = tf['cv_max'][elbo_idx]
            cd_m = tf['cd_max'][elbo_idx]
            e_safe = (cv_t <= TARGET_UPPER) and (cv_m <= SAFETY_VOL_UPPER) and (cd_m <= SAFETY_CHEMO_UPPER)

            feas = (tf['cv_terminal'] <= TARGET_UPPER) & \
                   (tf['cv_max'] <= SAFETY_VOL_UPPER) & \
                   (tf['cd_max'] <= SAFETY_CHEMO_UPPER)
            r_safe = True if feas.sum() > 0 else e_safe

            total += 1
            if e_safe: elbo_safe += 1
            if r_safe: ra_safe += 1

    if total > 0:
        print(f"{tau:>4} | {elbo_safe/total:>9.1%} | {ra_safe/total:>9.1%} | {total:>5}")

print("\nOriginal SR_0 values (with patient_types):")
print("  tau=2: ELBO=85.0%, RA=94.4%")
print("  tau=4: ELBO=83.2%, RA=95.6%")
print("  tau=6: ELBO=79.8%, RA=97.0%")
print("  tau=8: ELBO=74.4%, RA=97.0%")
print("\nTheoretical bound (Theorem 2): SR_hidden >= SR_0 - psi(Gamma, tau)")
print("  Patient_types has 3 values; effective Gamma depends on confounding strength")
PYEOF

echo ""
echo "=== Tarring results ==="
cd /root/VCIP
tar czf /root/s72_results.tar.gz my_outputs/cancer_sim_cont/22/coeff_4/VCIP/train/True/case_infos/
echo "Download: scp -P 25003 root@69.157.137.231:/root/s72_results.tar.gz ."
echo "Done."
